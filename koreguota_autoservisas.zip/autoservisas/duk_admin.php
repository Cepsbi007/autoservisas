<?php
require 'includes/header.php';
reikalautiPrisijungimo('administratorius');

if ($_POST && isset($_POST['prideti'])) {
    $klausimas = trim($_POST['klausimas']);
    $atsakymas = trim($_POST['atsakymas']);
    if ($klausimas && $atsakymas) {
        $stmt = $pdo->prepare("INSERT INTO duk (klausimas, atsakymas) VALUES (?, ?)");
        $stmt->execute([$klausimas, $atsakymas]);
    }
}

$duk = $pdo->query("SELECT * FROM duk ORDER BY id")->fetchAll();
?>
<h2>DUK valdymas</h2>

<h3>Pridėti naują</h3>
<form method="post">
    <input type="text" name="klausimas" placeholder="Klausimas" required>
    <textarea name="atsakymas" placeholder="Atsakymas" required></textarea>
    <button type="submit" name="prideti">Pridėti</button>
</form>

<h3>Esami DUK</h3>
<table>
    <tr><th>ID</th><th>Klausimas</th><th>Rodyti</th><th>Veiksmai</th></tr>
    <?php foreach ($duk as $d): ?>
        <tr>
            <td><?= $d['id'] ?></td>
            <td><?= htmlspecialchars(substr($d['klausimas'], 0, 50)) ?>...</td>
            <td><?= $d['rodyti'] ? 'Taip' : 'Ne' ?></td>
            <td>
                <a href="duk_redaguoti.php?id=<?= $d['id'] ?>">Redaguoti</a> |
                <a href="duk_trinti.php?id=<?= $d['id'] ?>" onclick="return confirm('Ar tikrai?')">Trinti</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include 'includes/footer.php'; ?>
