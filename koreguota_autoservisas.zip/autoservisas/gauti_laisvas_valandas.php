<?php
require 'includes/db.php';
header('Content-Type: application/json');

$paslauga_id = $_GET['paslauga_id'] ?? null;

$sql = "SELECT v.id, v.vardas, v.pavarde, p.trukme_min
        FROM vartotojai v
        JOIN meistrai_paslaugos mp ON v.id = mp.meistras_id
        JOIN paslaugos p ON mp.paslauga_id = p.id
        WHERE v.tipas = 'meistras'";
if ($paslauga_id) $sql .= " AND p.id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute($paslauga_id ? [$paslauga_id] : []);
$meistrai = $stmt->fetchAll();

$events = [];
$start_date = new DateTime();
$end_date = (clone $start_date)->modify('+14 days');

for ($d = $start_date; $d <= $end_date; $d->modify('+1 day')) {
    foreach ($meistrai as $m) {
        $data = $d->format('Y-m-d');
        $current = new DateTime("$data 08:00");
        $end = new DateTime("$data 18:00");

        while ($current < $end) {
            $slot_end = (clone $current)->modify("+{$m['trukme_min']} minutes");
            if ($slot_end > $end) break;

            $laisva = true;

            // Tikrinti užsakymus
            $stmt = $pdo->prepare("SELECT pradzios_laikas, ADDTIME(pradzios_laikas, SEC_TO_TIME(p.trukme_min*60)) AS pabaiga
                FROM uzsakymai u JOIN paslaugos p ON u.paslauga_id = p.id
                WHERE u.meistras_id = ? AND u.data = ? AND u.busena = 'patvirtintas'");
            $stmt->execute([$m['id'], $data]);
            foreach ($stmt->fetchAll() as $u) {
                $u_start = new DateTime("$data {$u['pradzios_laikas']}");
                $u_end = new DateTime("$data {$u['pabaiga']}");
                if ($current < $u_end && $slot_end > $u_start) {
                    $laisva = false;
                    break;
                }
            }

            // Tikrinti uždarytas valandas
            if ($laisva) {
                $stmt = $pdo->prepare("SELECT pradzios_laikas, pabaigos_laikas FROM uzdarytos_valandos WHERE meistras_id = ? AND data = ?");
                $stmt->execute([$m['id'], $data]);
                foreach ($stmt->fetchAll() as $u) {
                    $u_start = new DateTime("$data {$u['pradzios_laikas']}");
                    $u_end = new DateTime("$data {$u['pabaigos_laikas']}");
                    if ($current < $u_end && $slot_end > $u_start) {
                        $laisva = false;
                        break;
                    }
                }
            }

            if ($laisva) {
                $events[] = [
                    'title' => $m['vardas'] . ' – ' . $m['trukme_min'] . ' min',
                    'start' => $current->format('Y-m-d\TH:i:s'),
                    'url' => "klientas/uzsakymas.php?meistras_id={$m['id']}&paslauga_id={$paslauga_id}&data={$data}&laikas={$current->format('H:i')}"
                ];
            }
            $current->modify("+30 minutes");
        }
    }
}
echo json_encode($events);
