<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<?php
require 'includes/header.php';
reikalautiPrisijungimo('administratorius');

$vartotojai = $pdo->query("
    SELECT id, vardas, pavarde, el_pastas, tipas 
    FROM vartotojai 
    ORDER BY tipas, vardas
")->fetchAll();
?>
<h2>Vartotojų valdymas</h2>

<?php if (empty($vartotojai)): ?>
    <p class="info">Nėra vartotojų.</p>
<?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Vardas</th>
                <th>Pavardė</th>
                <th>El. paštas</th>
                <th>Tipas</th>
                <th>Paslaugos</th>
                <th>Veiksmai</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($vartotojai as $v): ?>
                <tr>
                    <td><?= $v['id'] ?></td>
                    <td><?= htmlspecialchars($v['vardas']) ?></td>
                    <td><?= htmlspecialchars($v['pavarde']) ?></td>
                    <td><?= htmlspecialchars($v['el_pastas']) ?></td>
                    <td>
                        <span class="badge <?= $v['tipas'] ?>">
                            <?= ucfirst($v['tipas']) ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($v['tipas'] === 'meistras'): ?>
                            <a href="admin/meistro_paslaugos.php?id=<?= $v['id'] ?>" class="btn small">
                                Keisti paslaugas
                            </a>
                        <?php else: ?>
                            <span class="info">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="keisti_tipa.php?id=<?= $v['id'] ?>" class="btn small">Keisti tipą</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<p class="back-link">
    <a href="admin/index.php">Grįžti į administravimo panelę</a>
</p>

<?php include 'includes/footer.php'; ?>
