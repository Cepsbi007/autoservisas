<?php
require '../includes/header.php';
reikalautiPrisijungimo('meistras');

$data = $_GET['data'] ?? date('Y-m-d');
$stmt = $pdo->prepare("SELECT u.*, p.pavadinimas, v.vardas AS kliento_vardas FROM uzsakymai u JOIN paslaugos p ON u.paslauga_id = p.id JOIN vartotojai v ON u.klientas_id = v.id WHERE u.meistras_id = ? AND u.data = ? ORDER BY u.pradzios_laikas");
$stmt->execute([$_SESSION['user']['id'], $data]);
$uzsakymai = $stmt->fetchAll();
?>
<h2>Jūsų darbai <?= $data ?></h2>
<form>
    <input type="date" name="data" value="<?= $data ?>" onchange="this.form.submit()">
</form>

<table>
    <tr><th>Laikas</th><th>Klientas</th><th>Paslauga</th><th>Būsena</th></tr>
    <?php foreach ($uzsakymai as $u): ?>
        <tr>
            <td><?= $u['pradzios_laikas'] ?></td>
            <td><?= htmlspecialchars($u['kliento_vardas']) ?></td>
            <td><?= htmlspecialchars($u['pavadinimas']) ?></td>
            <td><?= $u['busena'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<h3>Uždaryti valandas</h3>
<form method="post" action="uzdaryti_valandas.php">
    <input type="date" name="data" required>
    <input type="time" name="pradzios_laikas" required>
    <input type="time" name="pabaigos_laikas" required>
    <button type="submit">Uždaryti</button>
</form>

<?php include '../includes/footer.php'; ?>
