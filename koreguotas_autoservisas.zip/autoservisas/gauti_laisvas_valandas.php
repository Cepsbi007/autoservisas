<?php
require 'includes/db.php';
header('Content-Type: application/json');
date_default_timezone_set('Europe/Vilnius');

$paslauga_id = $_GET['paslauga_id'] ?? null;
if (!$paslauga_id) {
    echo json_encode([]);
    exit;
}

$events = [];
$start_date = new DateTime();
$end_date = (clone $start_date)->modify('+14 days');

$stmt = $pdo->prepare("SELECT trukme_min FROM paslaugos WHERE id = ?");
$stmt->execute([$paslauga_id]);
$trukme = $stmt->fetchColumn();
if (!$trukme) {
    echo json_encode([]);
    exit;
}

for ($d = clone $start_date; $d <= $end_date; $d->modify('+1 day')) {
    $data = $d->format('Y-m-d');
    $current = new DateTime("$data 08:00");
    $end = new DateTime("$data 18:00");

    while ($current < $end) {
        $slot_end = (clone $current)->modify("+$trukme minutes");
        if ($slot_end > $end) break;

        $laisva = false;

        $stmt = $pdo->prepare("
            SELECT v.id FROM vartotojai v
            JOIN meistrai_paslaugos mp ON v.id = mp.meistras_id
            WHERE mp.paslauga_id = ? AND v.tipas = 'meistras'
        ");
        $stmt->execute([$paslauga_id]);
        $meistrai = $stmt->fetchAll(PDO::FETCH_COLUMN);

        foreach ($meistrai as $meistras_id) {
            $konfliktas = $pdo->prepare("
                SELECT 1 FROM uzsakymai u
                JOIN paslaugos p ON u.paslauga_id = p.id
                WHERE u.meistras_id = ? 
                  AND u.data = ? 
                  AND u.busena IN ('patvirtintas', 'įvykdytas')
                  AND u.pradzios_laikas < ? 
                  AND ADDTIME(u.pradzios_laikas, SEC_TO_TIME(p.trukme_min*60)) > ?
            ");
            $konfliktas->execute([$meistras_id, $data, $slot_end->format('H:i:s'), $current->format('H:i:s')]);
            if ($konfliktas->rowCount() > 0) continue;

            $uzdaryta = $pdo->prepare("
                SELECT 1 FROM uzdarytos_valandos
                WHERE meistras_id = ? AND data = ?
                AND pradzios_laikas < ? AND pabaigos_laikas > ?
            ");
            $uzdaryta->execute([$meistras_id, $data, $slot_end->format('H:i:s'), $current->format('H:i:s')]);
            if ($uzdaryta->rowCount() > 0) continue;

            $laisva = true;
            break;
        }

        if ($laisva) {
            $events[] = [
                'title' => 'Laisvas laikas',
                'start' => $current->format('Y-m-d\TH:i:s'),
                'color' => '#3788d8',
                'textColor' => 'white'
            ];
        }

        $current->modify('+30 minutes');
    }
}

echo json_encode($events);
?>
