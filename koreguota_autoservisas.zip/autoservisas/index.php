<?php
session_start();
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Autorius: [Jūsų vardas ir pavardė]</strong></p>
    <p>Sveiki atvykę į autoservisą! Prisijunkite arba registruokitės.</p>
    <p>
        <a href="prisijungimas.php">Prisijungti</a> |
        <a href="registracija.php">Registruotis</a> |
        <a href="duk.php">DUK</a>
    </p>
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
