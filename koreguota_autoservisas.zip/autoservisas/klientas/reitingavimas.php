<?php
require '../includes/header.php';
reikalautiPrisijungimo('klientas');

$uzsakymas_id = $_GET['id'] ?? null;
if (!$uzsakymas_id) die("Nenurodytas užsakymas.");

$stmt = $pdo->prepare("SELECT u.*, p.pavadinimas, v.vardas AS meistro_vardas FROM uzsakymai u JOIN paslaugos p ON u.paslauga_id = p.id JOIN vartotojai v ON u.meistras_id = v.id WHERE u.id = ? AND u.klientas_id = ? AND u.busena = 'įvykdytas'");
$stmt->execute([$uzsakymas_id, $_SESSION['user']['id']]);
$uzsakymas = $stmt->fetch();

if (!$uzsakymas) die("Užsakymas nerastas arba negalima vertinti.");

if ($_POST) {
    $ivertinimas = $_POST['ivertinimas'];
    $komentaras = trim($_POST['komentaras']);

    if ($ivertinimas < 1 || $ivertinimas > 5) {
        $klaida = "Reitingas turi būti nuo 1 iki 5.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO reitingai (uzsakymas_id, ivertinimas, komentaras) VALUES (?, ?, ?)");
        $stmt->execute([$uzsakymas_id, $ivertinimas, $komentaras]);
        $sekme = "Ačiū už įvertinimą!";
    }
}
?>
<h2>Įvertinti paslaugą</h2>
<p>Paslauga: <strong><?= htmlspecialchars($uzsakymas['pavadinimas']) ?></strong></p>
<p>Meistras: <strong><?= htmlspecialchars($uzsakymas['meistro_vardas']) ?></strong></p>

<?php if (!empty($klaida)): ?><div class="klaida"><p><?= $klaida ?></p></div><?php endif; ?>
<?php if (!empty($sekme)): ?><div class="sekme"><p><?= $sekme ?></p></div><?php endif; ?>

<form method="post">
    <label>Įvertinimas (1–5):</label>
    <select name="ivertinimas" required>
        <option>1</option><option>2</option><option>3</option><option>4</option><option>5</option>
    </select>
    <label>Komentaras:</label>
    <textarea name="komentaras" rows="3"></textarea>
    <button type="submit">Pateikti</button>
</form>

<?php include '../includes/footer.php'; ?>
