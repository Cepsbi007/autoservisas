<?php
require '../includes/header.php';
reikalautiPrisijungimo('klientas');

$paslaugos = $pdo->query("SELECT * FROM paslaugos")->fetchAll();
?>
<h2>Pasirinkite paslaugą</h2>
<form id="filtras">
    <select name="paslauga_id" onchange="this.form.submit()">
        <option value="">-- Visos paslaugos --</option>
        <?php foreach ($paslaugos as $p): ?>
            <option value="<?= $p['id'] ?>" <?= ($_GET['paslauga_id'] ?? '') == $p['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['pavadinimas']) ?> (<?= $p['trukme_min'] ?> min, <?= $p['kaina'] ?> €)
            </option>
        <?php endforeach; ?>
    </select>
</form>

<div id="calendar"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendar = new FullCalendar.Calendar(document.getElementById('calendar'), {
        initialView: 'timeGridWeek',
        slotMinTime: '08:00:00',
        slotMaxTime: '18:00:00',
        headerToolbar: { left: 'prev,next today', center: 'title', right: 'timeGridWeek,timeGridDay' },
        events: 'gauti_laisvas_valandas.php?paslauga_id=<?= $_GET['paslauga_id'] ?? "" ?>',
        eventClick: function(info) {
            if (confirm('Ar norite užsiregistruoti pas ' + info.event.title + '?')) {
                window.location = 'uzsakymas.php?start=' + encodeURIComponent(info.event.startStr);
            }
        }
    });
    calendar.render();
});
</script>

<?php include '../includes/footer.php'; ?>
