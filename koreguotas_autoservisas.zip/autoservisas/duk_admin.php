<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<?php
require 'includes/header.php';
reikalautiPrisijungimo('administratorius');

if ($_POST && isset($_POST['prideti'])) {
    $klausimas = trim($_POST['klausimas']);
    $atsakymas = trim($_POST['atsakymas']);
    if ($klausimas && $atsakymas) {
        $stmt = $pdo->prepare("INSERT INTO duk (klausimas, atsakymas, rodyti) VALUES (?, ?, 1)");
        $stmt->execute([$klausimas, $atsakymas]);
        $sekme = "DUK sėkmingai pridėtas!";
    } else {
        $klaida = "Užpildykite visus laukus.";
    }
}

$duk = $pdo->query("SELECT * FROM duk ORDER BY id DESC")->fetchAll();
?>
<h2>DUK valdymas</h2>

<?php if (isset($sekme)): ?>
    <div class="success"><p><?= $sekme ?></p></div>
<?php endif; ?>
<?php if (isset($klaida)): ?>
    <div class="error"><p><?= $klaida ?></p></div>
<?php endif; ?>

<h3>Pridėti naują DUK</h3>
<form method="post" class="form">
    <input type="text" name="klausimas" placeholder="Klausimas" required>
    <textarea name="atsakymas" placeholder="Atsakymas" rows="4" required></textarea>
    <button type="submit" name="prideti" class="btn">Pridėti DUK</button>
</form>

<h3>Esami DUK</h3>

<?php if (empty($duk)): ?>
    <p class="info">Nėra DUK.</p>
<?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Klausimas</th>
                <th>Rodyti</th>
                <th>Veiksmai</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($duk as $d): ?>
                <tr>
                    <td><?= $d['id'] ?></td>
                    <td><?= htmlspecialchars(mb_substr($d['klausimas'], 0, 60)) ?><?= mb_strlen($d['klausimas']) > 60 ? '...' : '' ?></td>
                    <td>
                        <span class="badge <?= $d['rodyti'] ? 'active' : 'inactive' ?>">
                            <?= $d['rodyti'] ? 'Taip' : 'Ne' ?>
                        </span>
                    </td>
                    <td>
                        <a href="duk_redaguoti.php?id=<?= $d['id'] ?>" class="btn small">Redaguoti</a>
                        <a href="duk_trinti.php?id=<?= $d['id'] ?>" 
                           class="btn small danger" 
                           onclick="return confirm('Ar tikrai norite ištrinti?')">
                            Trinti
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<p class="back-link">
    <a href="admin/index.php">Grįžti į administravimo panelę</a>
</p>

<?php include 'includes/footer.php'; ?>
