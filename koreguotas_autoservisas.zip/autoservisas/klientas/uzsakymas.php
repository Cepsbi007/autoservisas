<?php
require '../includes/header.php';
reikalautiPrisijungimo('klientas');

if (!isset($_GET['start'], $_GET['paslauga_id'], $_GET['meistras_id'])) {
    die("Trūksta duomenų užsakymui.");
}

$start_str = $_GET['start'];
if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/', $start_str)) {
    die("Neteisingas datos formatas.");
}

$start = DateTime::createFromFormat('Y-m-d\TH:i:s', $start_str, new DateTimeZone('Europe/Vilnius'));
if (!$start) die("Nepavyko apdoroti datos.");

$data = $start->format('Y-m-d');
$laikas = $start->format('H:i');
$paslauga_id = (int)$_GET['paslauga_id'];
$meistras_id = (int)$_GET['meistras_id'];

$stmt = $pdo->prepare("SELECT pavadinimas, trukme_min FROM paslaugos WHERE id = ?");
$stmt->execute([$paslauga_id]);
$paslauga = $stmt->fetch();
if (!$paslauga) die("Paslauga nerasta.");

$stmt = $pdo->prepare("SELECT CONCAT(vardas, ' ', pavarde) AS vardas FROM vartotojai WHERE id = ? AND tipas = 'meistras'");
$stmt->execute([$meistras_id]);
$meistras = $stmt->fetch();
if (!$meistras) die("Meistras nerastas.");

$pabaiga = (clone $start)->modify("+{$paslauga['trukme_min']} minutes");
$pabaigos_laikas = $pabaiga->format('H:i:s');
$pradzios_laikas = $start->format('H:i:s');

$klaidos = [];
$sekme = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Patikrinti, ar meistras laisvas
    $q = $pdo->prepare("
        SELECT COUNT(*) FROM uzsakymai u
        JOIN paslaugos p ON u.paslauga_id = p.id
        WHERE u.meistras_id = ? 
          AND u.data = ? 
          AND u.busena IN ('patvirtintas', 'įvykdytas')
          AND (
            u.pradzios_laikas < ? 
            AND ADDTIME(u.pradzios_laikas, SEC_TO_TIME(p.trukme_min * 60)) > ?
          )
    ");
    $q->execute([$meistras_id, $data, $pabaigos_laikas, $pradzios_laikas]);

    if ($q->fetchColumn() > 0) {
        $klaidos[] = "Atsiprašome, pasirinktas laikas jau užimtas.";
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO uzsakymai 
            (klientas_id, meistras_id, paslauga_id, data, pradzios_laikas, busena) 
            VALUES (?, ?, ?, ?, ?, 'patvirtintas')
        ");
        $stmt->execute([
            $_SESSION['user']['id'],
            $meistras_id,
            $paslauga_id,
            $data,
            $laikas . ':00'  
        ]);

        $sekme = "Užsakymas sėkmingai pateiktas!";
    }
}
?>

<h2>Užsakymo patvirtinimas</h2>

<div style="background:#f9f9f9; padding:15px; border-radius:8px; margin:20px 0;">
    <p><strong>Paslauga:</strong> <?= htmlspecialchars($paslauga['pavadinimas']) ?> (<?= $paslauga['trukme_min'] ?> min)</p>
    <p><strong>Meistras:</strong> <?= htmlspecialchars($meistras['vardas']) ?></p>
    <p><strong>Data:</strong> <?= $data ?> <strong>Laikas:</strong> <?= $laikas ?></p>
</div>

<?php if ($klaidos): ?>
    <div class="klaida" style="background:#ffebee; color:#c62828; padding:10px; border-radius:4px; margin:15px 0;">
        <?php foreach ($klaidos as $k): ?>
            <p><?= htmlspecialchars($k) ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if ($sekme): ?>
    <div class="sekme" style="background:#e8f5e9; color:#2e7d32; padding:15px; border-radius:4px; margin:20px 0;">
        <p><?= $sekme ?></p>
    </div>
    <p><a href="index.php" class="btn">Grįžti į kalendorių</a></p>
<?php else: ?>
    <form method="post" action="">
        <button type="submit" class="btn" style="font-size:16px; padding:12px 30px;">
            Patvirtinti užsakymą
        </button>
    </form>
<?php endif; ?>

<p style="margin-top: 30px;">
    <a href="index.php">← Grįžti į kalendorių</a>
</p>

<?php include '../includes/footer.php'; ?>
