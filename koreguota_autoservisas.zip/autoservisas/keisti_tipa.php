<?php
require 'includes/db.php';
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['tipas'] !== 'administratorius') {
    header("Location: prisijungimas.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) die("Nenurodytas vartotojas.");

$stmt = $pdo->prepare("SELECT tipas FROM vartotojai WHERE id = ?");
$stmt->execute([$id]);
$tipas = $stmt->fetchColumn();

if ($_POST) {
    $naujas_tipas = $_POST['tipas'];
    $stmt = $pdo->prepare("UPDATE vartotojai SET tipas = ? WHERE id = ?");
    $stmt->execute([$naujas_tipas, $id]);
    header("Location: vartotojai.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Keisti tipą | Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Autorius: [Jūsų vardas ir pavardė]</strong></p>
    <h2>Keisti vartotojo tipą</h2>

    <form method="post">
        <label>Tipas:</label>
        <select name="tipas" required>
            <option value="klientas" <?= $tipas == 'klientas' ? 'selected' : '' ?>>Klientas</option>
            <option value="meistras" <?= $tipas == 'meistras' ? 'selected' : '' ?>>Meistras</option>
            <option value="administratorius" <?= $tipas == 'administratorius' ? 'selected' : '' ?>>Administratorius</option>
        </select>
        <button type="submit">Išsaugoti</button>
    </form>
    <p><a href="vartotojai.php">Grįžti</a></p>
</div>
</body>
</html>
