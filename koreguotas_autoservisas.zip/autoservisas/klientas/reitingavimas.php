<?php
require '../includes/header.php';
reikalautiPrisijungimo('klientas');

$uzsakymas_id = $_GET['id'] ?? null;
if (!$uzsakymas_id || !is_numeric($uzsakymas_id)) {
    die("Nenurodytas užsakymas.");
}

// Gauti užsakymo info
$stmt = $pdo->prepare("
    SELECT u.*, p.pavadinimas, CONCAT(v.vardas, ' ', v.pavarde) AS meistro_vardas
    FROM uzsakymai u
    JOIN paslaugos p ON u.paslauga_id = p.id
    JOIN vartotojai v ON u.meistras_id = v.id
    WHERE u.id = ? AND u.klientas_id = ? AND u.busena = 'įvykdytas'
");
$stmt->execute([$uzsakymas_id, $_SESSION['user']['id']]);
$uzsakymas = $stmt->fetch();

if (!$uzsakymas) {
    die("Užsakymas nerastas arba negalima vertinti.");
}

// Patikrinti, ar jau įvertintas
$stmt = $pdo->prepare("SELECT 1 FROM reitingai WHERE uzsakymas_id = ?");
$stmt->execute([$uzsakymas_id]);
if ($stmt->rowCount() > 0) {
    die("Šis užsakymas jau įvertintas.");
}

$klaidos = [];
$sekme = '';

if ($_POST) {
    $ivertinimas = (int)($_POST['ivertinimas'] ?? 0);
    $komentaras = trim($_POST['komentaras'] ?? '');

    if ($ivertinimas < 1 || $ivertinimas > 5) {
        $klaidos[] = "Reitingas turi būti nuo 1 iki 5.";
    }
    if (empty($komentaras)) {
        $klaidos[] = "Komentaras privalomas.";
    }

    if (empty($klaidos)) {
        $stmt = $pdo->prepare("
            INSERT INTO reitingai (uzsakymas_id, ivertinimas, komentaras) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$uzsakymas_id, $ivertinimas, $komentaras]);
        $sekme = "Ačiū už įvertinimą!";
    }
}
?>
<h2>Įvertinti paslaugą</h2>
<p><strong>Paslauga:</strong> <?= htmlspecialchars($uzsakymas['pavadinimas']) ?></p>
<p><strong>Meistras:</strong> <?= htmlspecialchars($uzsakymas['meistro_vardas']) ?></p>
<p><strong>Data:</strong> <?= $uzsakymas['data'] ?> <?= $uzsakymas['pradzios_laikas'] ?></p>

<?php if (!empty($klaidos)): ?>
    <div class="klaida">
        <?php foreach ($klaidos as $k): ?><p><?= htmlspecialchars($k) ?></p><?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if ($sekme): ?>
    <div class="sekme"><p><?= $sekme ?></p></div>
    <p><a href="index.php">Grįžti</a></p>
<?php else: ?>
    <form method="post">
        <label>Įvertinimas (1–5):</label>
        <select name="ivertinimas" required>
            <option value="">-- Pasirinkite --</option>
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <option value="<?= $i ?>" <?= (isset($_POST['ivertinimas']) && $_POST['ivertinimas'] == $i) ? 'selected' : '' ?>>
                    <?= $i ?> žvaigždutė<?= $i > 1 ? 's' : '' ?>
                </option>
            <?php endfor; ?>
        </select>

        <label>Komentaras:</label>
        <textarea name="komentaras" rows="4" required><?= $_POST['komentaras'] ?? '' ?></textarea>

        <button type="submit">Pateikti įvertinimą</button>
    </form>
<?php endif; ?>

<p><a href="index.php">Grįžti į kalendorių</a></p>
<?php include '../includes/footer.php'; ?>
