<?php
require 'includes/header.php';
reikalautiPrisijungimo('administratorius');

$vartotojai = $pdo->query("SELECT * FROM vartotojai ORDER BY tipas, vardas")->fetchAll();
?>
<h2>Vartotojų valdymas</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Vardas</th>
        <th>Pavardė</th>
        <th>El. paštas</th>
        <th>Tipas</th>
        <th>Veiksmai</th>
    </tr>
    <?php foreach ($vartotojai as $v): ?>
        <tr>
            <td><?= $v['id'] ?></td>
            <td><?= htmlspecialchars($v['vardas']) ?></td>
            <td><?= htmlspecialchars($v['pavarde']) ?></td>
            <td><?= htmlspecialchars($v['el_pastas']) ?></td>
            <td><?= $v['tipas'] ?></td>
            <td>
                <a href="keisti_tipa.php?id=<?= $v['id'] ?>" style="color: #1a5fb4;">Keisti tipą</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include 'includes/footer.php'; ?>
