    <p style="text-align: center; margin-top: 30px; color: #666;">&copy; 2025 Autoservisas. Visos teisės saugomos.</p>
</div>
</body>
</html>
