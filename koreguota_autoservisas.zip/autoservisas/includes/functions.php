<?php
function arPrisijungta() {
    return isset($_SESSION['user']);
}

function reikalautiPrisijungimo($tipas = null) {
    if (!arPrisijungta()) {
        header("Location: ../prisijungimas.php");
        exit;
    }
    if ($tipas && $_SESSION['user']['tipas'] !== $tipas) {
        die("Prieiga draudžiama.");
    }
}
?>
