<?php
require 'includes/db.php';
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['tipas'] !== 'administratorius') {
    header("Location: prisijungimas.php");
    exit;
}

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM duk WHERE id = ?");
    $stmt->execute([$id]);
}
header("Location: duk_admin.php");
exit;
