<?php
require '../includes/header.php';
reikalautiPrisijungimo('administratorius');
?>
<h2>Visi reitingai</h2>

<?php
$reitingai = $pdo->query("
    SELECT 
        r.id,
        r.ivertinimas,
        r.komentaras,
        r.sukurta,
        p.pavadinimas AS paslauga,
        CONCAT(k.vardas, ' ', k.pavarde) AS klientas,
        CONCAT(m.vardas, ' ', m.pavarde) AS meistras,
        u.data,
        u.pradzios_laikas
    FROM reitingai r
    JOIN uzsakymai u ON r.uzsakymas_id = u.id
    JOIN paslaugos p ON u.paslauga_id = p.id
    JOIN vartotojai k ON u.klientas_id = k.id
    JOIN vartotojai m ON u.meistras_id = m.id
    ORDER BY r.sukurta DESC
")->fetchAll();

if (empty($reitingai)): ?>
    <p style="color: #666; font-style: italic;">Kol kas nėra jokių reitingų.</p>
<?php else: ?>
    <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
        <thead>
            <tr style="background: #f0f0f0;">
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Data / Laikas</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Klientas</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Meistras</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Paslauga</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Reitingas</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Komentaras</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reitingai as $r): ?>
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?= $r['data'] ?> <?= $r['pradzios_laikas'] ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?= htmlspecialchars($r['klientas']) ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?= htmlspecialchars($r['meistras']) ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?= htmlspecialchars($r['paslauga']) ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: center; font-size: 18px;">
                        <?= str_repeat('★', $r['ivertinimas']) ?>
                        <span style="font-size: 12px; color: #666;"> (<?= $r['ivertinimas'] ?>/5)</span>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?= nl2br(htmlspecialchars($r['komentaras'])) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<p style="margin-top: 30px;">
    <a href="index.php">Grįžti į administravimo panelę</a>
</p>

<?php include '../includes/footer.php'; ?>
