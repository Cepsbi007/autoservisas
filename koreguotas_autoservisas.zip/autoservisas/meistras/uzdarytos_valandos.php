<?php
require '../includes/header.php';
reikalautiPrisijungimo('meistras');

$meistras_id = $_SESSION['user']['id'];

if (isset($_GET['trinti']) && is_numeric($_GET['trinti'])) {
    $trinti_id = $_GET['trinti'];
    $stmt = $pdo->prepare("DELETE FROM uzdarytos_valandos WHERE id = ? AND meistras_id = ?");
    $stmt->execute([$trinti_id, $meistras_id]);
    $sekme = "Uždarytos valandos ištrintos!";
}

$stmt = $pdo->prepare("
    SELECT id, data, pradzios_laikas, pabaigos_laikas 
    FROM uzdarytos_valandos 
    WHERE meistras_id = ? 
    ORDER BY data DESC, pradzios_laikas
");
$stmt->execute([$meistras_id]);
$uzdarytos = $stmt->fetchAll();
?>
<h2>Jūsų uždarytos valandos</h2>

<?php if (isset($sekme)): ?>
    <div class="success"><p><?= $sekme ?></p></div>
<?php endif; ?>

<?php if (empty($uzdarytos)): ?>
    <p class="info">Nėra uždarytų valandų.</p>
<?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Data</th>
                <th>Nuo</th>
                <th>Iki</th>
                <th>Veiksmas</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($uzdarytos as $u): ?>
                <tr>
                    <td><?= $u['data'] ?></td>
                    <td><?= substr($u['pradzios_laikas'], 0, 5) ?></td>
                    <td><?= substr($u['pabaigos_laikas'], 0, 5) ?></td>
                    <td>
                        <a href="?trinti=<?= $u['id'] ?>" 
                           class="btn small danger"
                           onclick="return confirm('Ar tikrai norite ištrinti šias uždarytas valandas?')">
                            Trinti
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<p class="back-link">
    <a href="index.php">Grįžti į darbų sąrašą</a>
</p>

<?php include '../includes/footer.php'; ?>
