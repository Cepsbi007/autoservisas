<?php
session_start();
require 'includes/db.php';
$klaidos = [];

if ($_POST) {
    $el_pastas = trim($_POST['el_pastas']);
    $slaptazodis = $_POST['slaptazodis'];

    if (empty($el_pastas) || empty($slaptazodis)) {
        $klaidos[] = "Visi laukai privalomi.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM vartotojai WHERE el_pastas = ?");
        $stmt->execute([$el_pastas]);
        $user = $stmt->fetch();

        if ($user && password_verify($slaptazodis, $user['slaptazodis'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'vardas' => $user['vardas'],
                'tipas' => $user['tipas']
            ];
            session_regenerate_id(true);

            switch ($user['tipas']) {
                case 'klientas':
                    header("Location: klientas/index.php");
                    break;
                case 'meistras':
                    header("Location: meistras/index.php");
                    break;
                case 'administratorius':
                    header("Location: admin/index.php");
                    break;
            }
            exit;
        } else {
            $klaidos[] = "Neteisingas el. paštas arba slaptažodis.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Prisijungimas | Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Autorius: [Jūsų vardas ir pavardė]</strong></p>
    <h2>Prisijungimas</h2>

    <?php if (!empty($klaidos)): ?>
        <div class="klaida">
            <?php foreach ($klaidos as $k): ?><p><?= htmlspecialchars($k) ?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <input type="email" name="el_pastas" placeholder="El. paštas" value="<?= $_POST['el_pastas'] ?? '' ?>" required>
        <input type="password" name="slaptazodis" placeholder="Slaptažodis" required>
        <button type="submit">Prisijungti</button>
    </form>
    <p>Neturite paskyros? <a href="registracija.php">Registruotis</a></p>
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
