<?php
require '../includes/db.php';
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['tipas'] !== 'meistras') {
    header("Location: ../prisijungimas.php");
    exit;
}

if ($_POST) {
    $data = $_POST['data'];
    $pradzios = $_POST['pradzios_laikas'];
    $pabaigos = $_POST['pabaigos_laikas'];
    $meistras_id = $_SESSION['user']['id'];

    try {
        $stmt = $pdo->prepare("INSERT INTO uzdarytos_valandos (meistras_id, data, pradzios_laikas, pabaigos_laikas) VALUES (?, ?, ?, ?)");
        $stmt->execute([$meistras_id, $data, $pradzios, $pabaigos]);
        header("Location: index.php?data=$data&sekme=1");
    } catch (PDOException $e) {
        header("Location: index.php?data=$data&klaida=1");
    }
    exit;
}
?>
