<?php
require 'includes/db.php';
$duk = $pdo->query("SELECT * FROM duk WHERE rodyti = 1 ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>DUK | Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Autorius: [Jūsų vardas ir pavardė]</strong></p>
    <h2>Dažniausiai užduodami klausimai</h2>
    <?php foreach ($duk as $d): ?>
        <details>
            <summary><?= htmlspecialchars($d['klausimas']) ?></summary>
            <p><?= nl2br(htmlspecialchars($d['atsakymas'])) ?></p>
        </details>
    <?php endforeach; ?>
    <p><a href="index.php">Grįžti</a></p>
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
