<?php
require '../includes/header.php';
reikalautiPrisijungimo('administratorius');
?>
<h2>Administratoriaus panelė</h2>
<p>Sveiki! Čia galite valdyti sistemą.</p>
<ul>
    <li><a href="../vartotojai.php">Valdyti vartotojus</a></li>
    <li><a href="../duk_admin.php">Valdyti DUK</a></li>
    <li><a href="reitingai.php">Peržiūrėti reitingus</a></li>
</ul>
<p><a href="../atsijungti.php">Atsijungti</a></p>
<?php include '../includes/footer.php'; ?>
