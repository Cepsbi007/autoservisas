<?php
require '../includes/header.php';
reikalautiPrisijungimo('administratorius');

$meistras_id = $_GET['id'] ?? null;
if (!$meistras_id || !is_numeric($meistras_id)) {
    die("Nenurodytas meistras.");
}

$stmt = $pdo->prepare("SELECT vardas, pavarde FROM vartotojai WHERE id = ? AND tipas = 'meistras'");
$stmt->execute([$meistras_id]);
$meistras = $stmt->fetch();
if (!$meistras) {
    die("Meistras nerastas.");
}

$visos_paslaugos = $pdo->query("SELECT id, pavadinimas FROM paslaugos ORDER BY pavadinimas")->fetchAll();

$dabartines = $pdo->prepare("
    SELECT paslauga_id FROM meistrai_paslaugos WHERE meistras_id = ?
");
$dabartines->execute([$meistras_id]);
$dabartines_ids = $dabartines->fetchAll(PDO::FETCH_COLUMN);

if ($_POST) {
    $pasirinktos = $_POST['paslaugos'] ?? [];
    
    $stmt = $pdo->prepare("DELETE FROM meistrai_paslaugos WHERE meistras_id = ?");
    $stmt->execute([$meistras_id]);

    if (!empty($pasirinktos)) {
        $insert = $pdo->prepare("INSERT INTO meistrai_paslaugos (meistras_id, paslauga_id) VALUES (?, ?)");
        foreach ($pasirinktos as $paslauga_id) {
            if (in_array($paslauga_id, array_column($visos_paslaugos, 'id'))) {
                $insert->execute([$meistras_id, $paslauga_id]);
            }
        }
    }

    $sekme = "Meistro paslaugos sėkmingai atnaujintos!";
    $dabartines->execute([$meistras_id]);
    $dabartines_ids = $dabartines->fetchAll(PDO::FETCH_COLUMN);
}
?>
<h2>Meistro paslaugos: <?= htmlspecialchars($meistras['vardas'] . ' ' . $meistras['pavarde']) ?></h2>

<?php if (isset($sekme)): ?>
    <div class="success"><p><?= $sekme ?></p></div>
<?php endif; ?>

<form method="post" class="form">
    <label>Pasirinkite paslaugas, kurias teikia meistras:</label>
    <div style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; margin: 10px 0; border-radius: 4px;">
        <?php foreach ($visos_paslaugos as $p): ?>
            <label style="display: block; margin: 8px 0;">
                <input type="checkbox" name="paslaugos[]" value="<?= $p['id'] ?>"
                       <?= in_array($p['id'], $dabartines_ids) ? 'checked' : '' ?>>
                <?= htmlspecialchars($p['pavadinimas']) ?>
            </label>
        <?php endforeach; ?>
    </div>

    <button type="submit" class="btn">Išsaugoti paslaugas</button>
</form>

<p class="back-link">
    <a href="../vartotojai.php">Grįžti į vartotojų sąrašą</a>
</p>

<?php include '../includes/footer.php'; ?>
