<?php
require '../includes/header.php';
reikalautiPrisijungimo('klientas');
$paslaugos = $pdo->query("SELECT * FROM paslaugos ORDER BY pavadinimas")->fetchAll();
$paslauga_id = $_GET['paslauga_id'] ?? null;
$meistras_id = $_GET['meistras_id'] ?? null;

$meistrai = [];
if ($paslauga_id) {
    $stmt = $pdo->prepare("
        SELECT v.id, CONCAT(v.vardas, ' ', v.pavarde) AS vardas_pavarde
        FROM vartotojai v
        JOIN meistrai_paslaugos mp ON v.id = mp.meistras_id
        WHERE mp.paslauga_id = ? AND v.tipas = 'meistras'
        ORDER BY v.vardas
    ");
    $stmt->execute([$paslauga_id]);
    $meistrai = $stmt->fetchAll();
}

$dabar = new DateTime('now', new DateTimeZone('Europe/Vilnius'));
$stmt = $pdo->prepare("
    SELECT u.id AS uzsakymas_id, u.data, u.pradzios_laikas, u.busena,
           p.pavadinimas AS paslauga,
           CONCAT(v.vardas, ' ', v.pavarde) AS meistras,
           r.ivertinimas IS NOT NULL AS ivertintas
    FROM uzsakymai u
    JOIN paslaugos p ON u.paslauga_id = p.id
    JOIN vartotojai v ON u.meistras_id = v.id
    LEFT JOIN reitingai r ON r.uzsakymas_id = u.id
    WHERE u.klientas_id = ?
    ORDER BY u.data DESC, u.pradzios_laikas DESC
");
$stmt->execute([$_SESSION['user']['id']]);
$uzsakymai = $stmt->fetchAll();
?>

<h2>Sveiki, <?= htmlspecialchars($_SESSION['user']['vardas']) ?>!</h2>
<p><a href="../atsijungti.php">Atsijungti</a></p>

<h3 style="margin-top: 25px;">Jūsų užregistruoti vizitai</h3>
<?php if (empty($uzsakymai)): ?>
    <p style="color:#666; font-style:italic;">Kol kas neturite užsakymų.</p>
<?php else: ?>
    <table style="width:100%; margin-top:10px; border-collapse:collapse; font-size:14px;">
        <thead style="background:#f0f0f0;">
            <tr>
                <th style="padding:10px; text-align:left;">Data</th>
                <th style="padding:10px; text-align:left;">Laikas</th>
                <th style="padding:10px; text-align:left;">Meistras</th>
                <th style="padding:10px; text-align:left;">Paslauga</th>
                <th style="padding:10px; text-align:left;">Būsena</th>
                <th style="padding:10px; text-align:left;">Veiksmai</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($uzsakymai as $u):
                $uzsakymo_laikas = new DateTime($u['data'] . ' ' . $u['pradzios_laikas']);
                $praejusio_fono = ($uzsakymo_laikas < $dabar) ? 'background:#e8e8e8; opacity:0.9;' : '';
            ?>
                <tr style="<?= $praejusio_fono ?>">
                    <td style="padding:10px;"><?= $u['data'] ?></td>
                    <td style="padding:10px;"><?= substr($u['pradzios_laikas'], 0, 5) ?></td>
                    <td style="padding:10px;"><?= htmlspecialchars($u['meistras']) ?></td>
                    <td style="padding:10px;"><?= htmlspecialchars($u['paslauga']) ?></td>
                    <td style="padding:10px;">
                        <?= $u['busena'] === 'įvykdytas' ? '<span style="color:green;font-weight:bold;">Įvykdytas</span>' : '<span style="color:#0066cc;">Patvirtintas</span>' ?>
                    </td>
                    <td style="padding:10px;">
                        <?php if ($u['busena'] === 'įvykdytas' && !$u['ivertintas']): ?>
                            <a href="reitingavimas.php?id=<?= $u['uzsakymas_id'] ?>" style="color:#d32f2f;font-weight:bold;">Įvertinti</a>
                        <?php elseif ($u['ivertintas']): ?>
                            <span style="color:#666;">Jau įvertinta</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<h3 style="margin-top: 35px;">Naujo vizito rezervacija</h3>
<h4>Pasirinkite paslaugą</h4>
<form method="get">
    <select name="paslauga_id" required onchange="this.form.submit()">
        <option value="" disabled <?= !$paslauga_id ? 'selected' : '' ?>>-- Pasirinkite paslaugą --</option>
        <?php foreach ($paslaugos as $p): ?>
            <option value="<?= $p['id'] ?>" <?= $paslauga_id == $p['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['pavadinimas']) ?> (<?= $p['trukme_min'] ?> min, <?= $p['kaina'] ?> €)
            </option>
        <?php endforeach; ?>
    </select>
</form>

<?php if ($paslauga_id): ?>
    <h4 style="margin-top: 20px;">Pasirinkite meistrą</h4>
    <form method="get">
        <input type="hidden" name="paslauga_id" value="<?= $paslauga_id ?>">
        <select name="meistras_id" required onchange="this.form.submit()">
            <option value="" disabled <?= !$meistras_id ? 'selected' : '' ?>>-- Pasirinkite meistrą --</option>
            <?php foreach ($meistrai as $m): ?>
                <option value="<?= $m['id'] ?>" <?= $meistras_id == $m['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($m['vardas_pavarde']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
<?php endif; ?>

<?php if ($paslauga_id && $meistras_id): ?>
    <div id="calendar" style="margin-top: 30px;"></div>

    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/lt.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            locale: 'lt',
            initialView: 'timeGridWeek',
            slotMinTime: '08:00:00',
            slotMaxTime: '18:00:00',
            timeZone: 'local',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'timeGridWeek,timeGridDay'
            },
            buttonText: {
                today: 'Šiandien',
                week: 'Savaitė',
                day: 'Diena'
            },
            events: '../gauti_laisvas_valandas.php?paslauga_id=<?= $paslauga_id ?>&meistras_id=<?= $meistras_id ?>',
            eventContent: function(arg) {
                return { html: '<div style="padding:6px; font-size:13px; text-align:center;">Laisvas laikas</div>' };
            },
            eventClick: function(info) {
                if (confirm('Ar tikrai norite užsakyti šį laiką?\n\n' + info.event.start.toLocaleString('lt-LT'))) {
                    const d = info.event.start;
                    const iso = d.getFullYear() + '-' +
                                String(d.getMonth()+1).padStart(2,'0') + '-' +
                                String(d.getDate()).padStart(2,'0') + 'T' +
                                String(d.getHours()).padStart(2,'0') + ':' +
                                String(d.getMinutes()).padStart(2,'0') + ':00';
                    window.location = `uzsakymas.php?start=${iso}&paslauga_id=<?= $paslauga_id ?>&meistras_id=<?= $meistras_id ?>`;
                }
            }
        });
        calendar.render();
    });
    </script>
<?php else: ?>
    <p style="margin-top: 20px; color: #666; font-style: italic;">
        <?= $paslauga_id ? 'Pasirinkite meistrą, kad matytumėte laisvus laikus.' : 'Pasirinkite paslaugą, kad pradėtumėte rezervaciją.' ?>
    </p>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
