<?php
require '../includes/header.php';
reikalautiPrisijungimo('meistras');
$meistras_id = $_SESSION['user']['id'];
$data = $_GET['data'] ?? date('Y-m-d');

if (isset($_POST['pakeisti_busena']) && isset($_POST['uzsakymas_id'])) {
    $uzsakymas_id = $_POST['uzsakymas_id'];
    $nauja_busena = $_POST['busena'];
    $stmt = $pdo->prepare("
        UPDATE uzsakymai
        SET busena = ?
        WHERE id = ? AND meistras_id = ? AND busena = 'patvirtintas'
    ");
    $stmt->execute([$nauja_busena, $uzsakymas_id, $meistras_id]);
    if ($stmt->rowCount() > 0) {
        $sekme = "Būsena pakeista į '$nauja_busena'.";
    } else {
        $klaida = "Nepavyko pakeisti būsenos (galbūt užsakymas neegzistuoja arba jau įvykdytas).";
    }
}

$stmt = $pdo->prepare("
    SELECT u.id, u.data, u.pradzios_laikas, u.busena,
           p.pavadinimas,
           CONCAT(k.vardas, ' ', k.pavarde) AS kliento_vardas
    FROM uzsakymai u
    JOIN paslaugos p ON u.paslauga_id = p.id
    JOIN vartotojai k ON u.klientas_id = k.id
    WHERE u.meistras_id = ? AND u.data = ?
    ORDER BY u.pradzios_laikas
");
$stmt->execute([$meistras_id, $data]);
$uzsakymai = $stmt->fetchAll();
?>

<h2>Jūsų darbai <?= htmlspecialchars($data) ?></h2>
<p>Sveiki, <?= htmlspecialchars($_SESSION['user']['vardas']) ?>! <a href="../atsijungti.php">Atsijungti</a></p>

<?php if (isset($sekme)): ?>
    <div class="sekme"><p><?= $sekme ?></p></div>
<?php endif; ?>
<?php if (isset($klaida)): ?>
    <div class="klaida"><p><?= $klaida ?></p></div>
<?php endif; ?>

<form method="get" style="margin-bottom: 20px;">
    <label>Data:</label>
    <input type="date" name="data" value="<?= $data ?>" required>
    <button type="submit">Rodyti</button>
</form>

<?php if (empty($uzsakymai)): ?>
    <p>Šiandien nėra užsakymų.</p>
<?php else: ?>
    <table>
        <tr>
            <th>Laikas</th>
            <th>Klientas</th>
            <th>Paslauga</th>
            <th>Būsena</th>
            <th>Veiksmai</th>
        </tr>
        <?php foreach ($uzsakymai as $u): ?>
            <tr>
                <td><?= htmlspecialchars($u['pradzios_laikas']) ?></td>
                <td><?= htmlspecialchars($u['kliento_vardas']) ?></td>
                <td><?= htmlspecialchars($u['pavadinimas']) ?></td>
                <td>
                    <?php if ($u['busena'] === 'įvykdytas'): ?>
                        <strong style="color: green;">Įvykdytas</strong>
                    <?php elseif ($u['busena'] === 'patvirtintas'): ?>
                        <span style="color: orange;">Patvirtintas</span>
                    <?php else: ?>
                        <?= htmlspecialchars($u['busena']) ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($u['busena'] === 'patvirtintas'): ?>
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="uzsakymas_id" value="<?= $u['id'] ?>">
                            <select name="busena" required style="font-size: 12px; padding: 2px;">
                                <option value="įvykdytas">Įvykdytas</option>
                            </select>
                            <button type="submit" name="pakeisti_busena"
                                    style="font-size: 12px; padding: 2px 5px; margin-left: 5px;"
                                    onclick="return confirm('Ar tikrai paslauga įvykdyta?')">
                                Pakeisti
                            </button>
                        </form>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<h3>Uždaryti valandas</h3>
<form method="post" action="uzdaryti_valandas.php">
    <label>
        <input type="date" name="data" required
               placeholder="Data"
               title="Įveskite mėnesį, dieną ir metus"
               oninvalid="this.setCustomValidity('Įveskite mėnesį, dieną ir metus')"
               oninput="this.setCustomValidity('')">
    </label>

    <label>
        <input type="time" name="pradzios_laikas" required
               placeholder="Nuo"
               title="Įveskite uždarymo pradžios valandas, minutes ir dienos metą (AM/PM)"
               oninvalid="this.setCustomValidity('Įveskite uždarymo pradžios valandas, minutes ir dienos metą (AM/PM)')"
               oninput="this.setCustomValidity('')">
    </label>

    <label>
        <input type="time" name="pabaigos_laikas" required
               placeholder="Iki"
               title="Įveskite uždarymo pabaigos valandas, minutes ir dienos metą (AM/PM)"
               oninvalid="this.setCustomValidity('Įveskite uždarymo pabaigos valandas, minutes ir dienos metą (AM/PM)')"
               oninput="this.setCustomValidity('')">
    </label>

    <button type="submit">Uždaryti valandas</button>
</form>

<p style="margin-top: 15px;">
    <a href="uzdarytos_valandos.php" class="btn">Peržiūrėti uždarytas valandas</a>
</p>

<?php include '../includes/footer.php'; ?>
