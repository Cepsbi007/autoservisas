<?php
require '../includes/header.php';
reikalautiPrisijungimo('administratorius');
?>
<h2>Administratoriaus panelė</h2>
<ul>
    <li><a href="../vartotojai.php">Valdyti vartotojus</a></li>
    <li><a href="../duk_admin.php">Valdyti DUK</a></li>
</ul>
<?php include '../includes/footer.php'; ?>
