<?php
session_start();
require_once 'db.php';
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Autoservisas</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Autorius: Arminas Arlauskas</strong></p>
