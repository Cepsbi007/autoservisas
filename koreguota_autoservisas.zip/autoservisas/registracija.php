<?php
require 'includes/db.php';
$klaidos = [];

if ($_POST) {
    $vardas = trim($_POST['vardas']);
    $pavarde = trim($_POST['pavarde']);
    $el_pastas = trim($_POST['el_pastas']);
    $slaptazodis = $_POST['slaptazodis'];
    $slaptazodis2 = $_POST['slaptazodis2'];

    if (empty($vardas) || empty($pavarde) || empty($el_pastas) || empty($slaptazodis)) {
        $klaidos[] = "Visi laukai privalomi.";
    }
    if (!filter_var($el_pastas, FILTER_VALIDATE_EMAIL)) {
        $klaidos[] = "Neteisingas el. paštas.";
    }
    if ($slaptazodis !== $slaptazodis2) {
        $klaidos[] = "Slaptažodžiai nesutampa.";
    }
    if (strlen($slaptazodis) < 6) {
        $klaidos[] = "Slaptažodis turi būti bent 6 simbolių.";
    }

    $stmt = $pdo->prepare("SELECT id FROM vartotojai WHERE el_pastas = ?");
    $stmt->execute([$el_pastas]);
    if ($stmt->rowCount() > 0) {
        $klaidos[] = "Šis el. paštas jau registruotas.";
    }

    if (empty($klaidos)) {
        $hash = password_hash($slaptazodis, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO vartotojai (vardas, pavarde, el_pastas, slaptazodis) VALUES (?, ?, ?, ?)");
        $stmt->execute([$vardas, $pavarde, $el_pastas, $hash]);
        $sekme = "Registracija sėkminga! Galite prisijungti.";
    }
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Registracija | Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Autorius: [Jūsų vardas ir pavardė]</strong></p>
    <h2>Registracija</h2>

    <?php if (!empty($klaidos)): ?>
        <div class="klaida">
            <?php foreach ($klaidos as $k): ?><p><?= htmlspecialchars($k) ?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if (!empty($sekme)): ?>
        <div class="sekme"><p><?= $sekme ?></p></div>
    <?php endif; ?>

    <form method="post">
        <input type="text" name="vardas" placeholder="Vardas" value="<?= $_POST['vardas'] ?? '' ?>" required>
        <input type="text" name="pavarde" placeholder="Pavardė" value="<?= $_POST['pavarde'] ?? '' ?>" required>
        <input type="email" name="el_pastas" placeholder="El. paštas" value="<?= $_POST['el_pastas'] ?? '' ?>" required>
        <input type="password" name="slaptazodis" placeholder="Slaptažodis" required>
        <input type="password" name="slaptazodis2" placeholder="Pakartokite slaptažodį" required>
        <button type="submit">Registruotis</button>
    </form>
    <p>Jau turite paskyrą? <a href="prisijungimas.php">Prisijunkite</a></p>
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
