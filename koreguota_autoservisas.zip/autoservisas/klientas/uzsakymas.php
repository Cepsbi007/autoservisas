<?php
require '../includes/header.php';
reikalautiPrisijungimo('klientas');

if (!isset($_GET['start'])) {
    die("Nenurodyta data/laikas.");
}

$start = new DateTime($_GET['start']);
$data = $start->format('Y-m-d');
$laikas = $start->format('H:i');

$paslauga_id = $_GET['paslauga_id'] ?? null;
$meistras_id = $_GET['meistras_id'] ?? null;

if ($_POST) {
    $paslauga_id = $_POST['paslauga_id'];
    $meistras_id = $_POST['meistras_id'];

    $stmt = $pdo->prepare("SELECT trukme_min FROM paslaugos WHERE id = ?");
    $stmt->execute([$paslauga_id]);
    $trukme = $stmt->fetchColumn();

    $pabaiga = (clone $start)->modify("+{$trukme} minutes");

    // Tikrinti konfliktus
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM uzsakymai 
        WHERE meistras_id = ? AND data = ? AND busena = 'patvirtintas'
        AND (pradzios_laikas < ? AND ADDTIME(pradzios_laikas, SEC_TO_TIME(p.trukme_min*60)) > ?)
        FROM paslaugos p WHERE p.id = uzsakymai.paslauga_id
    ");
    $stmt->execute([$meistras_id, $data, $pabaiga->format('H:i:s'), $laikas]);
    if ($stmt->fetchColumn() > 0) {
        $klaida = "Šis laikas užimtas.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO uzsakymai (klientas_id, meistras_id, paslauga_id, data, pradzios_laikas) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$_SESSION['user']['id'], $meistras_id, $paslauga_id, $data, $laikas]);
        $sekme = "Užsakymas sėkmingai pateiktas!";
    }
}
?>
<h2>Užsakymas</h2>
<p>Data: <strong><?= $data ?></strong>, Laikas: <strong><?= $laikas ?></strong></p>

<?php if (!empty($klaida)): ?>
    <div class="klaida"><p><?= $klaida ?></p></div>
<?php endif; ?>
<?php if (!empty($sekme)): ?>
    <div class="sekme"><p><?= $sekme ?></p></div>
<?php endif; ?>

<form method="post">
    <label>Paslauga:</label>
    <select name="paslauga_id" required>
        <?php
        $stmt = $pdo->prepare("SELECT p.* FROM paslaugos p JOIN meistrai_paslaugos mp ON p.id = mp.paslauga_id WHERE mp.meistras_id = ?");
        $stmt->execute([$meistras_id]);
        foreach ($stmt->fetchAll() as $p): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['pavadinimas']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Meistras:</label>
    <select name="meistras_id" required>
        <?php
        $stmt = $pdo->query("SELECT id, vardas, pavarde FROM vartotojai WHERE tipas = 'meistras'");
        foreach ($stmt->fetchAll() as $m): ?>
            <option value="<?= $m['id'] ?>" <?= $meistras_id == $m['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($m['vardas'] . ' ' . $m['pavarde']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Patvirtinti užsakymą</button>
</form>

<?php include '../includes/footer.php'; ?>
