<?php
require 'includes/db.php';
$duk = $pdo->query("SELECT * FROM duk WHERE rodyti = 1 ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>DUK | Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Studentas: Arminas Arlauskas</strong></p>
    <h2>Dažniausiai užduodami klausimai</h2>

    <?php if (empty($duk)): ?>
        <p>Kol kas nėra DUK.</p>
    <?php else: ?>
        <?php foreach ($duk as $d): ?>
            <details style="margin-bottom: 15px; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                <summary style="font-weight: bold; cursor: pointer; color: #1a5fb4;">
                    <?= htmlspecialchars($d['klausimas']) ?>
                </summary>
                <p style="margin-top: 8px; padding-left: 10px;">
                    <?= nl2br(htmlspecialchars($d['atsakymas'])) ?>
                </p>
            </details>
        <?php endforeach; ?>
    <?php endif; ?>

    <p><a href="index.php">Grįžti į pradžią</a></p>
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
