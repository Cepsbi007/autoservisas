<?php
require 'includes/db.php';
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['tipas'] !== 'administratorius') {
    header("Location: prisijungimas.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) die("Nenurodytas DUK.");

$stmt = $pdo->prepare("SELECT * FROM duk WHERE id = ?");
$stmt->execute([$id]);
$duk = $stmt->fetch();

if ($_POST) {
    $klausimas = trim($_POST['klausimas']);
    $atsakymas = trim($_POST['atsakymas']);
    $rodyti = isset($_POST['rodyti']) ? 1 : 0;

    $stmt = $pdo->prepare("UPDATE duk SET klausimas = ?, atsakymas = ?, rodyti = ? WHERE id = ?");
    $stmt->execute([$klausimas, $atsakymas, $rodyti, $id]);
    header("Location: duk_admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Redaguoti DUK | Autoservisas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <h1>Autoservisas</h1>
    <p><strong>Studentas: Arminas Arlauskas</strong></p>
    <h2>Redaguoti DUK</h2>

    <form method="post">
        <input type="text" name="klausimas" value="<?= htmlspecialchars($duk['klausimas']) ?>" required>
        <textarea name="atsakymas" required><?= htmlspecialchars($duk['atsakymas']) ?></textarea>
        <label><input type="checkbox" name="rodyti" <?= $duk['rodyti'] ? 'checked' : '' ?>> Rodyti viešai</label>
        <button type="submit">Išsaugoti</button>
    </form>
    <p><a href="duk_admin.php">Grįžti</a></p>
</div>
</body>
</html>
